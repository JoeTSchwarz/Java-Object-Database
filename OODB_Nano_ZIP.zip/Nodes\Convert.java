
import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.zip.*;
import java.nio.file.*;
import java.nio.channels.*;
import java.util.concurrent.*;
import joeapp.odb.*;
/**
Joe Nartca (c)
*/
public class Convert {
  private static void save(String fName, HashMap<String, byte[]> cache) throws Exception {
    List<String> kLst = new ArrayList<>(cache.keySet());
    GZIPOutputStream go = new GZIPOutputStream(new FileOutputStream(fName, false), true);
    ODBOutputStream oos = new ODBOutputStream( );
    // format: KeyLength ObjectLength Key      Object
    //         2 bytes   4 bytes      n bytes  n bytes
    for (String key : kLst) {
      byte[] obj = cache.get(key);    // Obj
      oos.writeShort(key.length());   // key length
      oos.writeInt(obj.length);       // obj length
      oos.writeString(key);           // key
      oos.write(obj);                 // object
    }
    go.write(oos.toByteArray());
    go.flush( );
    go.close( );
  }
  public static void main(String... argvs) throws Exception {
    HashMap<String, byte[]> cache = new HashMap<>();
    if (argvs.length > 0) for (int i = 0; i < argvs.length; ++i) {
      File file = new File(argvs[i]);
      if (file.exists()) try {
        // NIO for the performance
        byte[] buf = Files.readAllBytes(file.toPath());
        if (buf.length > 0) {
          GZIPInputStream gi = new GZIPInputStream(new ODBInputStream(buf));
          ODBOutputStream oos = new ODBOutputStream();
          buf = new byte[65536]; // 64K
          for (int p = gi.read(buf); p > 0; p = gi.read(buf)) oos.write(buf, 0, p);
          gi.close();
          //
          ODBInputStream ois = new ODBInputStream(oos.toByteArray());
          while (ois.remainderLength() > 0) {
            int kL  = ois.readShort();
            int oL  = ois.readInt();
            String key = ois.readString(kL);
            if (key.charAt(0) == 0x00) {  //String
              while (key.charAt(0) == 0x00) key = key.substring(1);
              key = (char)0x00+key;
            } else if (key.charAt(0) == 0x01) { // POJO
              while (key.charAt(0) == 0x01) key = key.substring(1);
              key = (char)0x01+key;
            } else if (key.charAt(0) == 0x02) {  // long
              while (key.charAt(0) == 0x02) key = key.substring(1);
              key = (char)0x02+key;
            }
            cache.put(key, ois.readBytes(oL));
          }
          save(argvs[i], cache);
        }
      } catch (Exception ex) {
        //ex.printStackTrace();
      }
    }
  }
}
