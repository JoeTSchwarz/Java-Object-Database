import joeapp.odb.*;
//
public class Stock {
  public static void main(String... args) {
    try {
      ODBConnect dbcon = new ODBConnect("192.168.0.70", 8888, "tester", "test");
      System.out.println("Connected to OODB-Server@8888");
      dbcon.connect("Stock"); // create if needed
      if (!dbcon.isExisted("Stock", "TunaCan")) {
        dbcon.add("Stock", "TunaCan", new Items("Tuna", 0));
      } else {
        dbcon.lock("Stock", "TunaCan");
        dbcon.update("Stock", "TunaCan", new Items("Tuna", 0));
      }
      dbcon.commit("Stock");
      dbcon.save("Stock");
      dbcon.disconnect();
      //
      dbcon = new ODBConnect("192.168.0.70", 9999, "tester", "test");
      System.out.println("Connected to OODB-Server@9999");
      dbcon.connect("Stock"); // create if needed
      if (!dbcon.isExisted("Stock", "CocaBottle")) {
        // Object Items
        dbcon.add("Stock", "CocaBottle", new Items("CocaCola", 0));
      } else {
        dbcon.lock("Stock", "CocaBottle");
        dbcon.update("Stock", "CocaBottle", new Items("CocaCola", 0));
      }
      dbcon.commit("Stock");
      dbcon.save("Stock");
      dbcon.disconnect();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    System.exit(0);
  }
}

