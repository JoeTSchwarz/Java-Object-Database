import java.io.*;
import java.util.*;
import java.util.zip.*;
import joeapp.odb.EnDecrypt;
public class ListUsers {
  public static void main(String... a) throws Exception {
    String file = a[0];
    File fi = new File(file);
    if (fi.isDirectory()) {
      if (file.endsWith("/") || file.endsWith(File.separator)) file = file+"userlist";
      else file = file+"/userlist";
    } else {
      if (!file.endsWith("userlist")) throw new Exception(file+" must end with \"userlist\".");
    }
    List<String> uList = new ArrayList<String>();
    if (!fi.exists()) {
      System.out.println(a[0]+" is empty!");
      System.exit(0);
    }
    int n;
    System.out.println("Format: Password:UserID@Privileg\n--------------------------------");
    GZIPInputStream gin = new GZIPInputStream(new FileInputStream(file));
    String[] lst = (new String(gin.readAllBytes())).split("\n");
    for (String s : lst) System.out.println(EnDecrypt.decrypt(s));
    gin.close();
  }
}
