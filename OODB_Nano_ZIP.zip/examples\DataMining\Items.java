public class Items implements java.io.Serializable {
  public Items(String item, int cnt) {
    counter = cnt;
    name = item;
  }
  public int counter = 0;
  public String name;
}
