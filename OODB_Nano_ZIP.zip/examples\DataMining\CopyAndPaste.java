import javax.swing.*;
import java.awt.event.*;
import javax.swing.text.DefaultEditorKit;
// Joe Nartca (c)
/**
CopyAndPaste for J Components such as JTextField, JTextArea, etc.
*/
public class CopyAndPaste extends MouseAdapter {
  /**
   Constructor A pop-up menu "Copy/Paste" with the click of the right mouse-pad
   @param jcomp any Jcomponent. Example JTextArea, JtextField
  */
  public CopyAndPaste(JComponent jcomp) {
    this.jcomp = jcomp;
  }
  /**
  self-explained
  @param e MouseEvent
  */
  public void mousePressed(MouseEvent e){
    if (e.isPopupTrigger()) popup(e);
  }
  /**
  self-explained
  @param e MouseEvent
  */
  public void mouseReleased(MouseEvent e){
    if (e.isPopupTrigger())popup(e);
  }
 
  private void popup(MouseEvent e){
    //JoePopup menu = new JoePopup();
    JPopupMenu menu = new JPopupMenu();
    JMenuItem copy = new JMenuItem(jcomp.getActionMap().get(DefaultEditorKit.copyAction));
    copy.setAccelerator(KeyStroke.getKeyStroke((int)'C', InputEvent.CTRL_DOWN_MASK));
    copy.setText("Copy");
    menu.add(copy);
 
    JMenuItem paste = new JMenuItem(jcomp.getActionMap().get(DefaultEditorKit.pasteAction));
    paste.setAccelerator(KeyStroke.getKeyStroke((int)'P', InputEvent.CTRL_DOWN_MASK));
    paste.setText("Paste");
    menu.add(paste);
    menu.show(e.getComponent(), e.getX(), e.getY());
  }
  private JComponent jcomp;
}
